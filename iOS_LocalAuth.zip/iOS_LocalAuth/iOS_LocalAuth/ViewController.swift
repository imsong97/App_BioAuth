//
//  ViewController.swift
//  iOS_LocalAuth
//
//  Created by SONG YUN-HO on 2020/12/30.
//

import UIKit
import LocalAuthentication

class ViewController: UIViewController {
    
    @IBOutlet weak var startBtn:UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func start(_ sender:UIButton){
        let authContext = LAContext()
        
        var description:String!
        var error: NSError?
        
        if authContext.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error){
            switch authContext.biometryType {
            case .faceID:
                description = "Face ID 인증"
                break
            case .touchID:
                description = "Touch ID 인증"
                break
            case .none:
                break
            @unknown default:
                fatalError()
            }
            
            authContext.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: description) { (success, error) in
                if success {
                    // 성공시 동작
                    print("인증 성공")
                } else {
                    // 실패시 동작
                    print("인증 실패")
                    if let error = error {
                        print(error.localizedDescription)
                    }
                }
                
            }
        }
        
        
    }
}

